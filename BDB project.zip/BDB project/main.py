# This is a sample Python script.
import InputScreen


# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# open local alignment app
def OPEN_APP():
    InputScreen.DNA_PROTEIN_LF()
    # Use a breakpoint in the code line below to debug your script.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    OPEN_APP()
